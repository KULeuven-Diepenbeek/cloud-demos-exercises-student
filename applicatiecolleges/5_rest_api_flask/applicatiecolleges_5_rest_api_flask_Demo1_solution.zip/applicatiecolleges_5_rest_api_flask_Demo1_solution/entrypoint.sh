#!/bin/bash
pip3 install --no-cache-dir --break-system-packages -r /app/requirements.txt
python3 app.py